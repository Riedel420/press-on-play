import { AnchorBox } from './geometry';
import { FingerId } from '../features/nail-engine/types';

/**
 * Locked-in anchor boxes for each finger.
 */
export const anchors: Record<FingerId, AnchorBox> = {
  thumb:  { x: 790, y: 465, width: 100, height: 140 },
  index:  { x: 590, y: 115, width: 81,  height: 140 },
  middle: { x: 427, y: 45,  width: 79,  height: 140 },
  ring:   { x: 268, y: 90,  width: 75,  height: 140 },
  pinky:  { x: 125, y: 240, width: 70,  height: 140 },
};

export function getAnchor(finger: FingerId): AnchorBox {
  return anchors[finger];
}

export function listAnchors(): [FingerId, AnchorBox][] {
  return Object.entries(anchors) as [FingerId, AnchorBox][];
}

export function anchorCenter(box: AnchorBox): { cx: number; cy: number } {
  return { cx: box.x + box.width / 2, cy: box.y + box.height / 2 };
}