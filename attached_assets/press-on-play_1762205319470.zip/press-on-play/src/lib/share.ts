import { NailPreset } from './presets';

/**
 * Encode a preset into a compact string for sharing.
 */
export function encodePreset(preset: NailPreset): string {
  const json = JSON.stringify(preset);
  // Encode as base64-safe string
  return btoa(encodeURIComponent(json));
}

/**
 * Decode a preset string back into a NailPreset object.
 */
export function decodePreset(encoded: string): NailPreset | null {
  try {
    const json = decodeURIComponent(atob(encoded));
    return JSON.parse(json);
  } catch {
    return null;
  }
}

/**
 * Build a shareable URL containing the encoded preset.
 */
export function makeShareUrl(preset: NailPreset): string {
  const encoded = encodePreset(preset);
  const u = new URL(window.location.href);
  u.searchParams.set('preset', encoded);
  return u.toString();
}

/**
 * Read a preset from the current URL if present.
 */
export function getPresetFromUrl(): NailPreset | null {
  const params = new URLSearchParams(window.location.search);
  const encoded = params.get('preset');
  return encoded ? decodePreset(encoded) : null;
}