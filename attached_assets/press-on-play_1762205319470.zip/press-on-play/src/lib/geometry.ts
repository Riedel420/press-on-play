/**
 * Shared geometry types and helpers
 */

export type AnchorBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

/** Get the center point of a rectangle */
export function rectCenter(box: AnchorBox): { cx: number; cy: number } {
  return { cx: box.x + box.width / 2, cy: box.y + box.height / 2 };
}

/** Check if a point lies inside a rectangle */
export function rectContains(box: AnchorBox, px: number, py: number): boolean {
  return (
    px >= box.x &&
    px <= box.x + box.width &&
    py >= box.y &&
    py <= box.y + box.height
  );
}

/** Scale a rectangle around its center */
export function rectScale(box: AnchorBox, factor: number): AnchorBox {
  const { cx, cy } = rectCenter(box);
  const newW = box.width * factor;
  const newH = box.height * factor;
  return {
    x: cx - newW / 2,
    y: cy - newH / 2,
    width: newW,
    height: newH,
  };
}

/** Translate a rectangle by dx, dy */
export function rectTranslate(box: AnchorBox, dx: number, dy: number): AnchorBox {
  return {
    x: box.x + dx,
    y: box.y + dy,
    width: box.width,
    height: box.height,
  };
}

/** Stringify a rectangle for debugging */
export function rectToString(box: AnchorBox): string {
  return `${box.x},${box.y} ${box.width}×${box.height}`;
}