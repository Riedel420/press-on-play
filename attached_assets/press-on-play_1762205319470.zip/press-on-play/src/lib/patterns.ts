export type PatternSpec =
  | { kind: 'none' }
  | { kind: 'stripes'; color?: string; opacity?: number }
  | { kind: 'dots'; color?: string; opacity?: number }
  | { kind: 'marble'; seed?: number; opacity?: number };

export function buildPattern(
  width: number,
  height: number,
  spec: PatternSpec
): { defs?: string; fill?: string; opacity?: number; filter?: string } {
  switch (spec.kind) {
    case 'none':
      return {};
    case 'stripes': {
      const id = 'pat-stripes';
      return {
        defs: `
          <pattern id="${id}" patternUnits="userSpaceOnUse" width="8" height="8">
            <path d="M0,0 l8,8 M-2,2 l4,4 M6,-2 l4,4" 
              stroke="${spec.color || '#000'}" stroke-width="1" />
          </pattern>`,
        fill: `url(#${id})`,
        opacity: spec.opacity ?? 0.2,
      };
    }
    case 'dots': {
      const id = 'pat-dots';
      return {
        defs: `
          <pattern id="${id}" patternUnits="userSpaceOnUse" width="6" height="6">
            <circle cx="3" cy="3" r="1.5" fill="${spec.color || '#000'}" />
          </pattern>`,
        fill: `url(#${id})`,
        opacity: spec.opacity ?? 0.2,
      };
    }
    case 'marble': {
      const id = 'pat-marble';
      return {
        defs: `
          <filter id="${id}">
            <feTurbulence type="fractalNoise" baseFrequency="0.05" numOctaves="3" seed="${
              spec.seed || 1
            }" />
            <feColorMatrix type="saturate" values="0" />
          </filter>`,
        filter: `url(#${id})`,
        opacity: spec.opacity ?? 0.15,
      };
    }
    default:
      return {};
  }
}