export type ShapeToolsConfig = {
  cuticleDepth: boolean;
  tipRoundness: boolean;
  taper: boolean;
  squovalRadius: boolean;
};

export const defaultShapeTools: ShapeToolsConfig = {
  cuticleDepth: true,
  tipRoundness: true,
  taper: true,
  squovalRadius: true,
};