/**
 * Finish styles for nails.
 * Each finish can provide <defs> (gradients/filters) and attrs (fill/filter).
 */

export type FinishStyle =
  | 'none'
  | 'gloss'
  | 'matte'
  | 'chrome'
  | 'pearl'
  | 'shimmer'
  | 'opalimmer'
  | 'glittertop'
  | 'holographic';

export function buildFinish(
  kind: FinishStyle
): { defs?: string; attrs?: Record<string, string> } {
  switch (kind) {
    case 'none':
      return {};
    case 'gloss':
      return {
        defs: `
          <linearGradient id="finish-gloss-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="white" stop-opacity="0.6"/>
            <stop offset="50%" stop-color="white" stop-opacity="0"/>
          </linearGradient>
        `,
        attrs: { fill: 'url(#finish-gloss-grad)' },
      };
    case 'matte':
      return {
        attrs: { style: 'filter: brightness(0.9) contrast(0.9);' },
      };
    case 'chrome':
      return {
        defs: `
          <linearGradient id="finish-chrome-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#eee"/>
            <stop offset="50%" stop-color="#aaa"/>
            <stop offset="100%" stop-color="#eee"/>
          </linearGradient>
        `,
        attrs: { fill: 'url(#finish-chrome-grad)' },
      };
    case 'pearl':
      return {
        defs: `
          <radialGradient id="finish-pearl-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#fff" stop-opacity="0.8"/>
            <stop offset="100%" stop-color="#ccc" stop-opacity="0.2"/>
          </radialGradient>
        `,
        attrs: { fill: 'url(#finish-pearl-grad)' },
      };
    case 'shimmer':
      return {
        defs: `
          <linearGradient id="finish-shimmer-grad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="white" stop-opacity="0.3"/>
            <stop offset="50%" stop-color="white" stop-opacity="0"/>
            <stop offset="100%" stop-color="white" stop-opacity="0.3"/>
          </linearGradient>
        `,
        attrs: { fill: 'url(#finish-shimmer-grad)' },
      };
    case 'opalimmer':
      return {
        defs: `
          <linearGradient id="finish-opalimmer-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#fff" stop-opacity="0.6"/>
            <stop offset="100%" stop-color="#b0e0e6" stop-opacity="0.3"/>
          </linearGradient>
        `,
        attrs: { fill: 'url(#finish-opalimmer-grad)' },
      };
    case 'glittertop':
      return {
        defs: `
          <pattern id="finish-glittertop-pat" width="4" height="4" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="0.5" fill="white" opacity="0.8"/>
            <circle cx="3" cy="2" r="0.5" fill="white" opacity="0.6"/>
          </pattern>
        `,
        attrs: { fill: 'url(#finish-glittertop-pat)' },
      };
    case 'holographic':
      return {
        defs: `
          <linearGradient id="finish-holographic-grad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stop-color="red"/>
            <stop offset="20%" stop-color="orange"/>
            <stop offset="40%" stop-color="yellow"/>
            <stop offset="60%" stop-color="green"/>
            <stop offset="80%" stop-color="blue"/>
            <stop offset="100%" stop-color="violet"/>
          </linearGradient>
        `,
        attrs: { fill: 'url(#finish-holographic-grad)' },
      };
    default:
      return {};
  }
}