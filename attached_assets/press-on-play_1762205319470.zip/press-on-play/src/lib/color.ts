// src/lib/color.ts
// Placeholder for color utility functions if needed in the future.
// For now, colors are handled directly in components.

export {}; // To resolve TS1208: 'color.ts' cannot be compiled under '--isolatedModules'