import type { AnchorBox } from './geometry';
import type { NailShape, NailLength } from '../features/nail-engine/types';

export type { AnchorBox, NailShape, NailLength };

/**
 * Generate an SVG path string for a nail shape inside an anchor box.
 */
export function nailPath(shape: NailShape, length: NailLength, anchor: AnchorBox): string {
  const w = anchor.width;
  const hBase = anchor.height;
  const lengthScale = length === 'short' ? 0.9 : length === 'med' ? 1.1 : 1.35;
  const h = hBase * lengthScale;

  switch (shape) {
    case 'natural-round': return naturalRound(w, h);
    case 'oval':          return oval(w, h);
    case 'almond':        return almond(w, h);
    case 'square':        return square(w, h);
    case 'squoval':       return squoval(w, h);
    case 'coffin':        return coffin(w, h);
    case 'stiletto':      return stiletto(w, h);
    default:              return oval(w, h);
  }
}

/**
 * Wrap a path string with a translation transform for the anchor box.
 */
export function renderNailPath(d: string, anchor: AnchorBox): { transform: string; d: string } {
  return { transform: `translate(${anchor.x}, ${anchor.y})`, d };
}

// --- helpers ---
function cuticleCurve(w: number, h: number, ratio = 0.15): string {
  const y = h * ratio;
  return `M 0 ${y} Q ${w * 0.25} ${y * 0.2}, ${w * 0.5} 0 Q ${w * 0.75} ${y * 0.2}, ${w} ${y}`;
}

// --- shapes ---
function naturalRound(w: number, h: number): string {
  const r = w * 0.5;
  return [
    cuticleCurve(w, h, 0.15),
    `L ${w} ${h - r * 0.2}`,
    `Q ${w} ${h}, ${w - r} ${h}`,
    `L ${r} ${h}`,
    `Q 0 ${h}, 0 ${h - r * 0.2}`,
    `Z`,
  ].join(' ');
}

function oval(w: number, h: number): string {
  const tipY = h * 0.95;
  return [
    cuticleCurve(w, h, 0.15),
    `C ${w} ${h * 0.4}, ${w * 0.8} ${tipY}, ${w * 0.5} ${h}`,
    `C ${w * 0.2} ${tipY}, 0 ${h * 0.4}, 0 ${h * 0.15}`,
    `Z`,
  ].join(' ');
}

function almond(w: number, h: number): string {
  return [
    cuticleCurve(w, h, 0.18),
    `Q ${w * 0.9} ${h * 0.6}, ${w * 0.5} ${h}`,
    `Q ${w * 0.1} ${h * 0.7}, 0 ${h * 0.18}`,
    `Z`,
  ].join(' ');
}

function square(w: number, h: number): string {
  return [cuticleCurve(w, h, 0.12), `L ${w} ${h}`, `L 0 ${h}`, `Z`].join(' ');
}

function squoval(w: number, h: number): string {
  const r = w * 0.2;
  const y = h * 0.9;
  return [
    cuticleCurve(w, h, 0.12),
    `L ${w} ${y - r}`,
    `Q ${w} ${y}, ${w - r} ${y}`,
    `L ${r} ${y}`,
    `Q 0 ${y}, 0 ${y - r}`,
    `Z`,
  ].join(' ');
}

function coffin(w: number, h: number): string {
  const taper = w * 0.15;
  const tipY = h * 0.85;
  return [cuticleCurve(w, h, 0.12), `L ${w - taper} ${tipY}`, `L ${taper} ${tipY}`, `Z`].join(' ');
}

function stiletto(w: number, h: number): string {
  const cuticleStart = h * 0.18;
  return [
    `M 0 ${cuticleStart}`,
    `Q ${w * 0.25} 0, ${w * 0.5} 0`,
    `Q ${w * 0.75} 0, ${w} ${cuticleStart}`,
    `L ${w * 0.5} ${h}`,
    `Z`,
  ].join(' ');
}