import { NailShape, NailLength } from './nailPath';
import { ShapeToolsConfig } from './shapeTools';

export type NailPreset = {
  id: string;
  name: string;
  shape: NailShape;
  length: NailLength;
  baseColor: string;
  finish: string;
  cuticleRatio: number;
  shapeTools: ShapeToolsConfig;
  pattern?: {
    kind: 'none' | 'stripes' | 'dots' | 'marble';
    seed?: number;
    color?: string;
    opacity?: number;
  };
};

const STORAGE_KEY = 'pressonplay-presets';

export function savePreset(preset: NailPreset) {
  const all = loadPresets();
  const next = [...all.filter(p => p.id !== preset.id), preset];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export function loadPresets(): NailPreset[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function deletePreset(id: string) {
  const all = loadPresets().filter(p => p.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}