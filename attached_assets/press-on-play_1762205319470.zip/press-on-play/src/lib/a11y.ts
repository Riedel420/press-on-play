// src/lib/a11y.ts
// Placeholder for accessibility utility functions if needed in the future.
// For now, ARIA attributes are handled directly in components.

export {}; // To resolve TS1208: 'a11y.ts' cannot be compiled under '--isolatedModules'