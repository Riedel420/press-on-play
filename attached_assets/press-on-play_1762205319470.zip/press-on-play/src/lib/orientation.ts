import { FingerId } from '../features/nail-engine/types';

export const orientationByFinger: Record<FingerId, number> = {
  thumb:   -0,
  index:    0,
  middle:   0,
  ring:     0,
  pinky:    0,
};