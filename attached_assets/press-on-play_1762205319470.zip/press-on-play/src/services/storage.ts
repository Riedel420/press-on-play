import type { HandDesign } from '../features/nail-engine/types';

const LS_KEY = 'press-on-play:hand-design';

export async function saveHandDesign(hand: HandDesign) {
  localStorage.setItem(LS_KEY, JSON.stringify(hand));
}

export function loadHandDesign(fallback: HandDesign): HandDesign {
  const raw = localStorage.getItem(LS_KEY);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as HandDesign;
  } catch {
    return fallback;
  }
}