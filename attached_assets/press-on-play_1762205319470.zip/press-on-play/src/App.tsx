import React, { useState, useEffect } from 'react';
import { HandDesign, FingerId, NailDesign } from './features/nail-engine/types';
import { HandCanvas } from './components/HandCanvas';
import { NailControls } from './components/NailControls';
import { PresetBar } from './components/PresetBar';
import { NailPreset } from './lib/presets';
import { getPresetFromUrl } from './lib/share';

// New imports
import { OverlayControls } from './components/OverlayControls';
import { ExportButton } from './components/ExportButton';

// --- initial design builder ---
function makeDefaultHand(): HandDesign {
  const fingers: FingerId[] = ['thumb', 'index', 'middle', 'ring', 'pinky'];
  const base: NailDesign = {
    finger: 'thumb',
    baseColor: '#ffb6c1',
    finish: 'gloss',
    shape: 'oval',
    length: 'med',
    gradient: { kind: 'none', stops: [] },
    overlays: [],
  };
  const hand: Partial<HandDesign> = {};
  fingers.forEach(f => {
    hand[f] = { ...base, finger: f };
  });
  return hand as HandDesign;
}

export default function App() {
  const [hand, setHand] = useState<HandDesign>(makeDefaultHand);
  const [activeFinger, setActiveFinger] = useState<FingerId>('thumb');

  // Load preset from URL if present
  useEffect(() => {
    const preset = getPresetFromUrl();
    if (preset) {
      applyPreset(preset);
    }
  }, []);

  function applyPreset(p: NailPreset) {
    const fingers: FingerId[] = ['thumb', 'index', 'middle', 'ring', 'pinky'];
    const next: Partial<HandDesign> = {};
    fingers.forEach(f => {
      next[f] = {
        finger: f,
        baseColor: p.baseColor,
        finish: p.finish as any,
        shape: p.shape,
        length: p.length,
        gradient: { kind: 'none', stops: [] },
        overlays: [],
      };
    });
    setHand(next as HandDesign);
  }

  const currentPreset: NailPreset = {
    id: '',
    name: '',
    shape: hand[activeFinger].shape,
    length: hand[activeFinger].length,
    baseColor: hand[activeFinger].baseColor,
    finish: hand[activeFinger].finish,
    cuticleRatio: 0.15,
    shapeTools: {
      cuticleDepth: true,
      tipRoundness: true,
      taper: true,
      squovalRadius: true,
    },
    pattern: { kind: 'none' },
  };

  return (
    <div style={{ padding: '1rem', fontFamily: 'sans-serif' }}>
      <h1>Press-On Play™</h1>
      <HandCanvas
        hand={hand}
        activeFinger={activeFinger}
        onFingerSelect={setActiveFinger}
        pngWidth={1000}
        pngHeight={700}
        handImageUrl="/hand.png"
        showCalibration={false}
      />
      <PresetBar current={currentPreset} onLoadPreset={applyPreset} />

      {/* Controls for the active finger */}
      <NailControls
        design={hand[activeFinger]}
        onChange={(updated) =>
          setHand({ ...hand, [activeFinger]: updated })
        }
      />

      {/* Overlay controls and export button */}
      <OverlayControls />
      <ExportButton />
    </div>
  );
}