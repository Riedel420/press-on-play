export type Command<T> = { do: (s: T) => T; undo: (s: T) => T; label: string };

export class History<T> {
  private stack: Command<T>[] = [];
  private index = -1;

  apply(cmd: Command<T>, state: T): T {
    const next = cmd.do(state);
    this.stack = this.stack.slice(0, this.index + 1).concat(cmd);
    this.index++;
    return next;
  }
  undo(state: T): T {
    if (this.index < 0) return state;
    const cmd = this.stack[this.index];
    this.index--;
    return cmd.undo(state);
  }
  redo(state: T): T {
    if (this.index + 1 >= this.stack.length) return state;
    const cmd = this.stack[this.index + 1];
    this.index++;
    return cmd.do(state);
  }
  canUndo() { return this.index >= 0; }
  canRedo() { return this.index + 1 < this.stack.length; }
}