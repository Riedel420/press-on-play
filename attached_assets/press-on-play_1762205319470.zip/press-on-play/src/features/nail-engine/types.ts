export type FingerId = 'thumb' | 'index' | 'middle' | 'ring' | 'pinky';

export type NailShape =
  | 'natural-round'
  | 'oval'
  | 'almond'
  | 'square'
  | 'squoval'
  | 'coffin'
  | 'stiletto';

export type NailLength = 'short' | 'med' | 'long';

export type FinishStyle =
  | 'none'
  | 'gloss'
  | 'matte'
  | 'chrome'
  | 'pearl'
  | 'shimmer'
  | 'opalimmer'
  | 'glittertop'
  | 'holographic';

export type GradientStop = {
  offset: number;
  color: string;
  opacity?: number;
};

export type GradientSpec = {
  kind: 'none' | 'linear' | 'radial' | 'angle45' | 'chalkball';
  angle?: number;
  stops: GradientStop[];
};

export type OverlayTransform = {
  x: number;
  y: number;
  scale: number;
  rotate: number;
};

export type OverlayLayer = {
  id: string;
  type: 'sticker' | 'decal' | 'freehand';
  data: any;
  transform?: OverlayTransform;
};

export type NailDesign = {
  finger: FingerId;
  baseColor: string;
  finish: FinishStyle;
  shape: NailShape;
  length: NailLength;
  gradient: GradientSpec;
  overlays: OverlayLayer[];
};

export type HandDesign = Record<FingerId, NailDesign>;