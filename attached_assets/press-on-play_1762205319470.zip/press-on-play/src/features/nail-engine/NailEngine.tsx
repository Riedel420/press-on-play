import React from 'react';
import { HandDesign, FingerId } from './types';
import { anchors } from '../../lib/anchors';
import { nailPath, renderNailPath, AnchorBox } from '../../lib/nailPath';

type Props = {
  hand: HandDesign;
  activeFinger: FingerId;
  onFingerSelect: (finger: FingerId) => void;
};

export function NailEngine({ hand, activeFinger, onFingerSelect }: Props) {
  const fingers: FingerId[] = ['thumb', 'index', 'middle', 'ring', 'pinky'];

  return (
    <svg viewBox="0 0 1000 700" width={1000} height={700}>
      {fingers.map((finger) => {
        const design = hand[finger];
        const anchor: AnchorBox = anchors[finger];

        const d = nailPath(design.shape, design.length, anchor);
        const { transform } = renderNailPath(d, anchor);

        return (
          <g
            key={finger}
            transform={transform}
            onClick={() => onFingerSelect(finger)}
            style={{ cursor: 'pointer' }}
          >
            <path
              d={d}
              fill={design.baseColor}
              stroke={finger === activeFinger ? 'gold' : '#ccc'}
              strokeWidth={finger === activeFinger ? 2 : 0.6}
            />
          </g>
        );
      })}
    </svg>
  );
}