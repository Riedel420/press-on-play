// src/features/nail-engine/NailPreview.tsx
import React from 'react';
import { NailDesign } from './types';
import { NailCanvas } from '../../components/NailCanvas';

type Props = { design: NailDesign; onClick?: () => void };

export function NailPreview({ design, onClick }: Props) {
  return (
    <button type="button" onClick={onClick} style={{ padding: 8, border: '1px solid #ddd', borderRadius: 8, background: '#fff' }}>
      <NailCanvas design={design} />
    </button>
  );
}