import type { Catalog } from './types';

let catalog: Catalog | null = null;

export async function loadCatalog(): Promise<Catalog> {
  if (catalog) return catalog;
  const res = await fetch('/catalog.json');
  const data = (await res.json()) as Catalog;
  // TODO: schema validation if needed
  catalog = data;
  return data;
}

export function getAssetById(id: string) {
  if (!catalog) return null;
  return catalog.assets.find(a => a.id === id) || null;
}