type EntitlementState = {
  ownedPacks: Set<string>;
};

const KEY = 'press-on-play:entitlements';
let state: EntitlementState = load() || { ownedPacks: new Set(['core']) };

export function hasAsset(assetId: string): boolean {
  const packId = getPackIdForAsset(assetId);
  return packId ? state.ownedPacks.has(packId) : false;
}

export function ownPack(packId: string) {
  state.ownedPacks.add(packId);
  save();
}

function getPackIdForAsset(assetId: string): string | null {
  const raw = localStorage.getItem('press-on-play:catalog');
  if (!raw) return null;
  try {
    const catalog = JSON.parse(raw);
    const asset = catalog.assets.find((a: any) => a.id === assetId);
    return asset?.packId || null;
  } catch {
    return null;
  }
}

function save() {
  localStorage.setItem(KEY, JSON.stringify({ ownedPacks: Array.from(state.ownedPacks) }));
}

function load(): EntitlementState | null {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    return { ownedPacks: new Set(parsed.ownedPacks) };
  } catch {
    return null;
  }
}