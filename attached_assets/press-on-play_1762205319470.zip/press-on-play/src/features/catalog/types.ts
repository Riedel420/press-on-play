export type CatalogAsset = {
  id: string;
  kind: 'decal' | 'effect';
  label: string;
  svg?: string;      // inline path data
  sprite?: string;   // optional external reference
  tags: string[];
  packId: string;
};

export type CatalogPack = { id: string; name: string; price?: number; free?: boolean; assets: string[] };
export type Catalog = { version: number; packs: CatalogPack[]; assets: CatalogAsset[] };