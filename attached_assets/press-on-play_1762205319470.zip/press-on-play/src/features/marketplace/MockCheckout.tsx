import React, { useState, useEffect } from 'react';
import { loadCatalog } from '../catalog/store';
import { ownPack } from '../catalog/Entitlements';

export const MockCheckout: React.FC = () => {
  const [packs, setPacks] = useState<any[]>([]);
  useEffect(() => { loadCatalog().then((c) => setPacks(c.packs)); }, []);
  const purchase = (id: string) => {
    // Simulate success/failure
    const ok = Math.random() > 0.1;
    if (ok) { ownPack(id); alert(`Unlocked pack: ${id}`); } else { alert(`Payment failed for pack: ${id}`); }
  };
  return (
    <section aria-label="Marketplace">
      <h3>Marketplace</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {packs.map((p) => (
          <li key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span>{p.name} {p.free ? '(Free)' : `($${p.price})`}</span>
            <button onClick={() => purchase(p.id)} disabled={p.free}>Unlock</button>
          </li>
        ))}
      </ul>
    </section>
  );
};