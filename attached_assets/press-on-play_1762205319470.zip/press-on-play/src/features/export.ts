// src/features/export.ts
import { HandDesign } from './nail-engine/types'; // Corrected import path for types

export function exportHandToSVG(hand: HandDesign): string {
  // The HandDesign type no longer directly contains 'name'.
  // Using a generic name for now. For future: pass hand name explicitly or retrieve from state.
  const exportedName = 'My Press-On Play Design'; // Updated generic name
  return `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="260">
    <text x="10" y="20" font-size="16">${exportedName}</text>
    <rect x="0" y="30" width="600" height="230" fill="#fff"/>
    <!-- TODO: inline each nail's rendered path and overlays for full fidelity -->
  </svg>`;
}

export async function svgToPNG(svgString: string, width = 600, height = 260): Promise<Blob> {
  const blob = new Blob([svgString], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const img = new Image();
  img.src = url;
  await img.decode();
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, width, height);
  URL.revokeObjectURL(url);
  const png = await new Promise<Blob>((resolve) => canvas.toBlob((b) => resolve(b!), 'image/png'));
  return png;
}