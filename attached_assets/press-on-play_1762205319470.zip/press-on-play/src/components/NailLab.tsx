import React, { useState } from 'react';
import { nailPath, renderNailPath, AnchorBox, NailShape, NailLength } from '../lib/nailPath';

export function NailLab() {
  const [shape, setShape] = useState<NailShape>('oval');
  const [length, setLength] = useState<NailLength>('med');

  const anchor: AnchorBox = { x: 0, y: 0, width: 100, height: 200 };

  // Generate path with 3 args only (shape, length, anchor)
  const d = nailPath(shape, length, anchor);
  const { transform } = renderNailPath(d, anchor);

  return (
    <div>
      <h3>NailLab</h3>
      <svg viewBox="0 0 200 300" width={200} height={300}>
        <path d={d} transform={transform} fill="#ffb6c1" stroke="#333" />
      </svg>
      <div>
        <label>
          Shape:
          <select value={shape} onChange={e => setShape(e.target.value as NailShape)}>
            <option value="natural-round">natural-round</option>
            <option value="oval">oval</option>
            <option value="almond">almond</option>
            <option value="square">square</option>
            <option value="squoval">squoval</option>
            <option value="coffin">coffin</option>
            <option value="stiletto">stiletto</option>
          </select>
        </label>
        <label>
          Length:
          <select value={length} onChange={e => setLength(e.target.value as NailLength)}>
            <option value="short">short</option>
            <option value="med">med</option>
            <option value="long">long</option>
          </select>
        </label>
      </div>
    </div>
  );
}