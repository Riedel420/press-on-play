import React, { useEffect } from 'react';
import { OverlayLayer } from '../features/nail-engine/types'; // Ensure OverlayLayer is correctly imported

type Props = {
  layer: OverlayLayer;
  onChange: (next: Partial<OverlayLayer>) => void;
  width: number;
  height: number;
};

export const TransformHandles: React.FC<Props> = ({ layer, onChange, width, height }) => {
  useEffect(() => {
    const opts = { passive: false } as any;
    const prevent = (e: Event) => {
      e.preventDefault();
    };
    // Type casting for non-standard 'gesturestart' event
    document.addEventListener('gesturestart' as unknown as keyof DocumentEventMap, prevent as EventListener, opts);
    return () => {
      document.removeEventListener('gesturestart' as unknown as keyof DocumentEventMap, prevent as EventListener);
    };
  }, []);

  // Ensure cx and cy are always numbers and reference layer.transform for initial values
  // Default to center if transform is undefined, and its properties to their defaults
  const currentTransform = layer.transform || { x: 0.5, y: 0.5, scale: 1, rotate: 0 };
  const cx = currentTransform.x * width;
  const cy = currentTransform.y * height;

  const startDrag = (e: React.PointerEvent) => {
    const startX = e.clientX;
    const startY = e.clientY;
    const initTransform = currentTransform; // Use the always-defined currentTransform for initial values

    const onMove = (ev: PointerEvent) => {
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      const nx = clamp((initTransform.x * width + dx) / width, 0, 1);
      const ny = clamp((initTransform.y * height + dy) / height, 0, 1);
      onChange({
        transform: {
          ...initTransform, // Spread existing transform to maintain scale/rotate
          x: nx,
          y: ny,
        },
      });
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startRotate = (e: React.PointerEvent) => {
    const startX = e.clientX;
    const startY = e.clientY;
    const initTransform = currentTransform; // Use the always-defined currentTransform for initial values
    const initialRotation = initTransform.rotate;

    const onMove = (ev: PointerEvent) => {
      const angleRad = Math.atan2(ev.clientY - cy, ev.clientX - cx);
      const currentRotation = angleRad * (180 / Math.PI);
      const snappedRotation = ev.shiftKey ? Math.round(currentRotation / 15) * 15 : currentRotation;
      onChange({
        transform: {
          ...initTransform, // Spread existing transform to maintain x/y/scale
          rotate: snappedRotation,
        },
      });
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const startScale = (e: React.PointerEvent) => {
    const startY = e.clientY;
    const initTransform = currentTransform; // Use the always-defined currentTransform for initial values
    const initialScale = initTransform.scale;

    const onMove = (ev: PointerEvent) => {
      const delta = (startY - ev.clientY) / 200;
      onChange({
        transform: {
          ...initTransform, // Spread existing transform to maintain x/y/rotate
          scale: clamp(initialScale + delta, 0.25, 3),
        },
      });
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  return (
    <g transform={`translate(${cx}, ${cy})`}>
      <circle cx={0} cy={0} r={18} fill="transparent" onPointerDown={startDrag} />
      <circle cx={0} cy={-40} r={10} fill="transparent" onPointerDown={startRotate} />
      <rect x={20} y={20} width={16} height={16} fill="transparent" onPointerDown={startScale} />
    </g>
  );
};

function clamp(n: number, min: number, max: number) { return Math.max(min, Math.min(max, n)); }