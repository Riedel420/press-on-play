import React, { useEffect, useState } from 'react';
import { NailPreset, loadPresets, savePreset, deletePreset } from '../lib/presets';
import { makeShareUrl } from '../lib/share';

type Props = {
  current: NailPreset; // snapshot of the current design
  onLoadPreset: (preset: NailPreset) => void;
};

export function PresetBar({ current, onLoadPreset }: Props) {
  const [presets, setPresets] = useState<NailPreset[]>([]);

  useEffect(() => {
    setPresets(loadPresets());
  }, []);

  function handleSave() {
    const p: NailPreset = {
      ...current,
      id: current.id || Date.now().toString(),
      name: current.name || `Design ${presets.length + 1}`,
    };
    savePreset(p);
    setPresets(loadPresets());
  }

  function handleDelete(id: string) {
    deletePreset(id);
    setPresets(loadPresets());
  }

  return (
    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', margin: '1rem 0' }}>
      <button onClick={handleSave}>Save Preset</button>
      {presets.map(p => (
        <div
          key={p.id}
          style={{
            border: '1px solid #ddd',
            padding: '0.5rem',
            borderRadius: 6,
            minWidth: 120,
          }}
        >
          <div style={{ fontWeight: 600 }}>{p.name}</div>
          <div style={{ fontSize: 12, opacity: 0.8 }}>
            {p.shape} / {p.length}
          </div>
          <div style={{ display: 'flex', gap: '0.25rem', marginTop: 6 }}>
            <button onClick={() => onLoadPreset(p)}>Load</button>
            <button onClick={() => alert(makeShareUrl(p))}>Share</button>
            <button onClick={() => handleDelete(p.id)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}