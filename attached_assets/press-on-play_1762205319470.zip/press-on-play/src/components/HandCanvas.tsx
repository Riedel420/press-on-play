import React from 'react';
import { HandDesign, FingerId } from '../features/nail-engine/types';
import { anchors } from '../lib/anchors';
import { nailPath, renderNailPath, AnchorBox } from '../lib/nailPath';
import { rectCenter } from '../lib/geometry';
import { buildFinish } from '../lib/finishes';
import { PatternSpec, buildPattern } from '../lib/patterns';

type Props = {
  hand: HandDesign;
  activeFinger: FingerId;
  onFingerSelect: (finger: FingerId) => void;
  handImageUrl?: string;
  pngWidth: number;
  pngHeight: number;
  showCalibration?: boolean;
  cuticleRatio?: number;
  pattern?: PatternSpec;
};

export function HandCanvas({
  hand,
  activeFinger,
  onFingerSelect,
  handImageUrl = '/hand.png',
  pngWidth,
  pngHeight,
  showCalibration = false,
  cuticleRatio = 0.15,
  pattern = { kind: 'none' },
}: Props) {
  const fingers: FingerId[] = ['thumb', 'index', 'middle', 'ring', 'pinky'];

  const pat = buildPattern(pngWidth, pngHeight, pattern);

  const finishKinds = new Set(Object.values(hand).map(d => d.finish));
  const finishDefs = Array.from(finishKinds).map(k => buildFinish(k).defs).join('');

  return (
    <svg viewBox={`0 0 ${pngWidth} ${pngHeight}`} width={pngWidth} height={pngHeight}>
      <defs dangerouslySetInnerHTML={{ __html: (pat.defs || '') + (finishDefs || '') }} />
      <image
        href={handImageUrl}
        x="0"
        y="0"
        width={pngWidth}
        height={pngHeight}
        preserveAspectRatio="xMidYMid meet"
      />

      {showCalibration &&
        fingers.map((f) => {
          const a = anchors[f];
          return (
            <rect
              key={`cal-${f}`}
              x={a.x}
              y={a.y}
              width={a.width}
              height={a.height}
              fill="none"
              stroke="green"
              strokeDasharray="4"
            />
          );
        })}

      {fingers.map((finger) => {
        const design = hand[finger];
        const anchor: AnchorBox = anchors[finger];

        const dLocal = nailPath(design.shape, design.length, anchor);
        const { transform: tTranslate } = renderNailPath(dLocal, anchor);

        const { cx, cy } = rectCenter(anchor);
        const localFlip = `rotate(180 ${cx} ${cy})`;

        const transform = `${tTranslate} ${localFlip}`;
        const isActive = finger === activeFinger;

        const fin = buildFinish(design.finish).attrs;

        return (
          <g
            key={finger}
            role="button"
            aria-label={finger}
            data-finger={finger}
            transform={transform}
            onClick={() => onFingerSelect(finger)}
            style={{ cursor: 'pointer' }}
          >
            <path
              d={dLocal}
              fill={design.baseColor}
              stroke={isActive ? 'gold' : '#ccc'}
              strokeWidth={isActive ? 2 : 0.6}
              strokeLinejoin="round"
              strokeLinecap="round"
              {...fin}
            />

            {pattern.kind !== 'none' && (
              <path
                d={dLocal}
                fill={pat.fill}
                opacity={pat.opacity}
                filter={(pat as any).filter}
                pointerEvents="none"
              />
            )}

            {(design.finish === 'gloss' ||
              design.finish === 'pearl' ||
              design.finish === 'opalimmer' ||
              design.finish === 'holographic') && (
              <path
                d={dLocal}
                fill={`url(#finish-${design.finish}-grad)`}
                opacity={0.9}
                pointerEvents="none"
              />
            )}
          </g>
        );
      })}
    </svg>
  );
}