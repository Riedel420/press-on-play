// src/components/ExportButton.tsx
import React from 'react';

export function ExportButton() {
  function handleExport() {
    // Placeholder: implement real PNG export later
    console.log('Export PNG clicked');
  }

  return (
    <button onClick={handleExport}>Export PNG</button>
  );
}