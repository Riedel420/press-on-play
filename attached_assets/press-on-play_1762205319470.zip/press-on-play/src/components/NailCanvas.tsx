import React from 'react';
import { NailDesign } from '../features/nail-engine/types';
import { nailPath, renderNailPath, AnchorBox, NailShape, NailLength } from '../lib/nailPath';
import { anchors } from '../lib/anchors';

type Props = {
  handImageUrl?: string; // default: /hand.png
  design: NailDesign;
  width?: number;
  height?: number;
};

export function NailCanvas({
  handImageUrl = '/hand.png',
  design,
  width = 360,
  height = 640,
}: Props) {
  const anchor: AnchorBox = anchors[design.finger];
  const nailPathData = nailPath(design.shape as NailShape, design.length as NailLength, anchor);
  const { transform: translateTransform, d: localPath } = renderNailPath(nailPathData, anchor);

  const cx = anchor.x + anchor.width / 2;
  const cy = anchor.y + anchor.height / 2;
  const nailGroupTransform = `${translateTransform} rotate(180 ${cx} ${cy})`;

  const id = (name: string) => `${name}-${design.finger}`;
  const gradientId = id('grad');
  const shimmerId = id('shimmer');

  return (
    <svg viewBox={`0 0 ${width} ${height}`} width={width} height={height}>
      <image
        href={handImageUrl}
        x="0"
        y="0"
        width={width}
        height={height}
        preserveAspectRatio="xMidYMid meet"
      />

      <defs>
        {design.gradient?.kind && design.gradient.kind !== 'none' && (
          <>
            {(design.gradient.kind === 'linear' || design.gradient.kind === 'angle45') && (
              <linearGradient
                id={gradientId}
                x1="0%"
                y1="0%"
                x2="100%"
                y2="0%"
                gradientTransform={
                  design.gradient.angle !== undefined
                    ? `rotate(${design.gradient.angle}, ${anchor.width / 2}, ${anchor.height / 2})`
                    : undefined
                }
              >
                {design.gradient.stops.map((s, i) => (
                  <stop key={i} offset={`${s.offset * 100}%`} stopColor={s.color} />
                ))}
              </linearGradient>
            )}
            {(design.gradient.kind === 'radial' || design.gradient.kind === 'chalkball') && (
              <radialGradient id={gradientId}>
                {design.gradient.stops.map((s, i) => (
                  <stop key={i} offset={`${s.offset * 100}%`} stopColor={s.color} />
                ))}
              </radialGradient>
            )}
          </>
        )}

        {design.finish === 'shimmer' && (
          <filter id={shimmerId}>
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.8"
              numOctaves="1"
              stitchTiles="stitch"
            />
            <feColorMatrix type="saturate" values="0.6" />
            <feBlend mode="screen" in2="SourceGraphic" />
          </filter>
        )}
      </defs>

      <g transform={nailGroupTransform}>
        <path
          d={localPath}
          fill={
            design.gradient?.kind && design.gradient.kind !== 'none'
              ? `url(#${gradientId})`
              : design.baseColor
          }
          filter={design.finish === 'shimmer' ? `url(#${shimmerId})` : undefined}
          style={{ mixBlendMode: design.finish === 'opalimmer' ? 'overlay' : undefined }}
        />

        {design.finish === 'glittertop' &&
          Array.from({ length: 120 }).map((_, i) => (
            <circle
              key={i}
              cx={(i * 57) % anchor.width}
              cy={(i * 33) % anchor.height}
              r={(i % 2) + 0.5}
              fill="#ffffff"
              opacity={0.7}
            />
          ))}
      </g>
    </svg>
  );
}