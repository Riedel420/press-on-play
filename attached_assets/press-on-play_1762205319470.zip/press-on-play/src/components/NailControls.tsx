import React from 'react';
import {
  NailShape,
  NailLength,
  FinishStyle,
  NailDesign,
} from '../features/nail-engine/types';

type Props = {
  design: NailDesign;
  onChange: (updated: NailDesign) => void;
};

const shapes: NailShape[] = [
  'natural-round',
  'oval',
  'almond',
  'square',
  'squoval',
  'coffin',
  'stiletto',
];

const lengths: NailLength[] = ['short', 'med', 'long'];

const finishes: FinishStyle[] = [
  'none',
  'gloss',
  'matte',
  'chrome',
  'pearl',
  'shimmer',
  'opalimmer',
  'glittertop',
  'holographic',
];

export function NailControls({ design, onChange }: Props) {
  function handleChange<K extends keyof NailDesign>(key: K, value: NailDesign[K]) {
    onChange({ ...design, [key]: value });
  }

  return (
    <div
      style={{
        border: '1px solid #ddd',
        padding: '1rem',
        borderRadius: 6,
        marginTop: '1rem',
        maxWidth: 400,
      }}
    >
      <h3 style={{ marginTop: 0 }}>Controls for {design.finger}</h3>

      {/* Base color */}
      <div style={{ marginBottom: '0.5rem' }}>
        <label htmlFor="baseColor">Base color hex:</label>{' '}
        <input
          id="baseColor"
          type="color"
          aria-label="Base color hex"
          value={design.baseColor}
          onChange={(e) => handleChange('baseColor', e.target.value)}
        />
      </div>

      {/* Shape */}
      <div style={{ marginBottom: '0.5rem' }}>
        <label htmlFor="shape">Shape:</label>{' '}
        <select
          id="shape"
          aria-label="Shape"
          value={design.shape}
          onChange={(e) => handleChange('shape', e.target.value as NailShape)}
        >
          {shapes.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {/* Length */}
      <div style={{ marginBottom: '0.5rem' }}>
        <label htmlFor="length">Length:</label>{' '}
        <select
          id="length"
          aria-label="Length"
          value={design.length}
          onChange={(e) => handleChange('length', e.target.value as NailLength)}
        >
          {lengths.map((l) => (
            <option key={l} value={l}>
              {l}
            </option>
          ))}
        </select>
      </div>

      {/* Finish */}
      <fieldset style={{ marginBottom: '0.5rem' }}>
        <legend>Finish</legend>
        {finishes.map((f) => (
          <label key={f} style={{ marginRight: '0.5rem' }}>
            <input
              type="radio"
              name="finish"
              value={f}
              checked={design.finish === f}
              onChange={() => handleChange('finish', f)}
            />
            {f}
          </label>
        ))}
      </fieldset>
    </div>
  );
}