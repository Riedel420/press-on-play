// src/components/OverlayControls.tsx
import React, { useState } from 'react';

export function OverlayControls() {
  const [overlays, setOverlays] = useState<string[]>([]);

  function addOverlay(name: string) {
    setOverlays([...overlays, name]);
  }

  return (
    <div style={{ marginTop: '1rem' }}>
      <button onClick={() => addOverlay('Star')}>Add Star</button>

      <ul role="list" aria-label="Overlay layers">
        {overlays.map((o, i) => (
          <li key={i}>{o}</li>
        ))}
      </ul>
    </div>
  );
}