import { render, screen } from '@testing-library/react';
import App from './App';

test('renders Press-On Play™ heading', () => {
  render(<App />);
  const headingElement = screen.getByRole('heading', { name: /Press-On Play™/i });
  expect(headingElement).toBeInTheDocument();
});