import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../../App';

// Mock localStorage for preset tests
beforeEach(() => {
  let store: Record<string, string> = {};
  const localStorageMock = {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
  Object.defineProperty(window, 'localStorage', {
    value: localStorageMock,
    writable: true,
  });
});

describe('App integration', () => {
  it('renders the app title', () => {
    render(<App />);
    expect(screen.getByText(/Press-On Play/i)).toBeInTheDocument();
  });

  it('renders HandCanvas and NailControls', () => {
    render(<App />);
    // HandCanvas renders an SVG
    expect(document.querySelector('svg')).toBeInTheDocument();
    // NailControls renders a label
    expect(screen.getByText(/Controls for/i)).toBeInTheDocument();
  });

  it('allows saving a preset and shows it in PresetBar', () => {
    render(<App />);
    const saveBtn = screen.getByText(/Save Preset/i);
    fireEvent.click(saveBtn);
    expect(screen.getByText(/Design 1/i)).toBeInTheDocument();
  });

  it('updates nail color via NailControls', () => {
    render(<App />);
    const colorInput = screen.getByLabelText(/Color/i);
    fireEvent.change(colorInput, { target: { value: '#123456' } });
    // After update, the current preset should reflect new color
    const saveBtn = screen.getByText(/Save Preset/i);
    fireEvent.click(saveBtn);
    expect(screen.getByText(/Design 1/i)).toBeInTheDocument();
  });
});