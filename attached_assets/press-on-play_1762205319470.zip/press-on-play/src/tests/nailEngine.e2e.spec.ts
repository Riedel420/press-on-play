// Polyfill for environments where TransformStream isn't global
import { TransformStream } from 'stream/web';
(globalThis as any).TransformStream = TransformStream;

import { test, expect } from '@playwright/test';

test('first design flow: select finger, apply gradient, add overlay, export', async ({ page }) => {
  await page.goto('http://localhost:3000');
  await expect(page.getByRole('heading', { name: 'Press-On Play™' })).toBeVisible();

  await page.getByRole('tab', { name: 'middle' }).click();

  // Set base color
  await page.getByLabel('Base color hex').fill('#ff99cc');

  // Add overlay from palette
  await page.getByRole('button', { name: /Add Star/i }).click();
  await expect(page.getByRole('list', { name: 'Overlay layers' })).toContainText('Star');

  // Finish toggle
  await page.getByRole('radio', { name: 'shimmer' }).click();

  // Export
  await page.getByRole('button', { name: 'Export PNG' }).click();
});