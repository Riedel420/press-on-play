import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { NailControls } from '../../components/NailControls';
import { NailDesign } from '../../features/nail-engine/types';

const mockDesign: NailDesign = {
  finger: 'thumb',
  baseColor: '#f00',
  finish: 'gloss',
  shape: 'oval',
  length: 'med',
  gradient: { kind: 'none', stops: [] },
  overlays: [],
};

describe('NailControls', () => {
  it('renders controls for a nail design', () => {
    render(<NailControls design={mockDesign} onChange={() => {}} />);
    expect(screen.getByText(/Controls for thumb/i)).toBeInTheDocument();
  });

  it('calls onChange when color is changed', () => {
    const onChange = jest.fn();
    render(<NailControls design={mockDesign} onChange={onChange} />);
    const colorInput = screen.getByLabelText(/Color/i);
    fireEvent.change(colorInput, { target: { value: '#00ff00' } });
    expect(onChange).toHaveBeenCalled();
  });
});