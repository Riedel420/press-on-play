import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { HandCanvas } from '../../components/HandCanvas';
import { HandDesign } from '../../features/nail-engine/types';

const mockHand: HandDesign = {
  thumb: { finger: 'thumb', baseColor: '#f00', finish: 'gloss', shape: 'oval', length: 'med', gradient: { kind: 'none', stops: [] }, overlays: [] },
  index: { finger: 'index', baseColor: '#0f0', finish: 'matte', shape: 'square', length: 'short', gradient: { kind: 'none', stops: [] }, overlays: [] },
  middle: { finger: 'middle', baseColor: '#00f', finish: 'chrome', shape: 'almond', length: 'long', gradient: { kind: 'none', stops: [] }, overlays: [] },
  ring: { finger: 'ring', baseColor: '#ff0', finish: 'pearl', shape: 'squoval', length: 'med', gradient: { kind: 'none', stops: [] }, overlays: [] },
  pinky: { finger: 'pinky', baseColor: '#0ff', finish: 'shimmer', shape: 'stiletto', length: 'short', gradient: { kind: 'none', stops: [] }, overlays: [] },
};

describe('HandCanvas', () => {
  it('renders an SVG with nails', () => {
    render(
      <HandCanvas
        hand={mockHand}
        activeFinger="thumb"
        onFingerSelect={() => {}}
        pngWidth={500}
        pngHeight={500}
      />
    );
    // Just assert that an <svg> exists
    expect(document.querySelector('svg')).toBeInTheDocument();
  });

  it('calls onFingerSelect when a nail is clicked', () => {
    const onSelect = jest.fn();
    render(
      <HandCanvas
        hand={mockHand}
        activeFinger="thumb"
        onFingerSelect={onSelect}
        pngWidth={500}
        pngHeight={500}
      />
    );
    const path = document.querySelector('path');
    fireEvent.click(path!);
    expect(onSelect).toHaveBeenCalled();
  });
});