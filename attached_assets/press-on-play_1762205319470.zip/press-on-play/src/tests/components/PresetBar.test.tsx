import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { PresetBar } from '../../components/PresetBar';
import { NailPreset } from '../../lib/presets';

const mockPreset: NailPreset = {
  id: '1',
  name: 'Test Preset',
  shape: 'oval',
  length: 'med',
  baseColor: '#f00',
  finish: 'gloss',
  cuticleRatio: 0.15,
  shapeTools: {
    cuticleDepth: true,
    tipRoundness: true,
    taper: true,
    squovalRadius: true,
  },
  pattern: { kind: 'none' },
};

describe('PresetBar', () => {
  it('renders Save Preset button', () => {
    render(<PresetBar current={mockPreset} onLoadPreset={() => {}} />);
    expect(screen.getByText(/Save Preset/i)).toBeInTheDocument();
  });

  it('renders presets after saving', () => {
    render(<PresetBar current={mockPreset} onLoadPreset={() => {}} />);
    fireEvent.click(screen.getByText(/Save Preset/i));
    expect(screen.getByText(/Test Preset/i)).toBeInTheDocument();
  });
});