import { AnchorBox, rectCenter, rectContains, rectScale, rectTranslate } from '../../lib/geometry';

describe('geometry.ts', () => {
  const mockAnchor: AnchorBox = { x: 0, y: 0, width: 100, height: 200 };

  it('computes rectCenter correctly', () => {
    const { cx, cy } = rectCenter(mockAnchor);
    expect(cx).toBe(50);
    expect(cy).toBe(100);
  });

  it('detects point containment', () => {
    expect(rectContains(mockAnchor, 50, 50)).toBe(true);
    expect(rectContains(mockAnchor, 200, 200)).toBe(false);
  });

  it('scales around center', () => {
    const scaled = rectScale(mockAnchor, 2);
    expect(scaled.width).toBe(200);
    expect(scaled.height).toBe(400);
    expect(rectCenter(scaled)).toEqual({ cx: 50, cy: 100 });
  });

  it('translates correctly', () => {
    const moved = rectTranslate(mockAnchor, 10, 20);
    expect(moved.x).toBe(10);
    expect(moved.y).toBe(20);
  });
});