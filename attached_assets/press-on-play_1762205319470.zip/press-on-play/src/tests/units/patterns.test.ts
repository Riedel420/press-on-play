import { buildPattern, PatternSpec } from '../../lib/patterns';

describe('patterns.ts', () => {
  const w = 100, h = 200;

  it('returns empty object for none', () => {
    const pat = buildPattern(w, h, { kind: 'none' });
    expect(pat).toEqual({});
  });

  it('builds stripes pattern', () => {
    const pat = buildPattern(w, h, { kind: 'stripes', color: '#123', opacity: 0.5 });
    expect(pat.defs).toContain('<pattern');
    expect(pat.fill).toContain('url(#pat-stripes)');
    expect(pat.opacity).toBe(0.5);
  });

  it('builds dots pattern', () => {
    const pat = buildPattern(w, h, { kind: 'dots' });
    expect(pat.defs).toContain('<circle');
    expect(pat.fill).toContain('url(#pat-dots)');
  });

  it('builds marble filter', () => {
    const pat = buildPattern(w, h, { kind: 'marble', seed: 42 });
    expect(pat.defs).toContain('<filter');
    expect(pat.filter).toContain('url(#pat-marble)');
  });
});