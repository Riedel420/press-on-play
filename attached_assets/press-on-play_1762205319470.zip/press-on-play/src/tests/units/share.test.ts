import { encodePreset, decodePreset, makeShareUrl } from '../../lib/share';
import { NailPreset } from '../../lib/presets';

describe('share.ts', () => {
  const preset: NailPreset = {
    id: '1',
    name: 'Test',
    shape: 'oval',
    length: 'med',
    baseColor: '#ff0000',
    finish: 'gloss',
    cuticleRatio: 0.15,
    shapeTools: {
      cuticleDepth: true,
      tipRoundness: true,
      taper: true,
      squovalRadius: true,
    },
    pattern: { kind: 'none' },
  };

  it('encodes and decodes a preset', () => {
    const encoded = encodePreset(preset);
    const decoded = decodePreset(encoded);
    expect(decoded?.name).toBe('Test');
    expect(decoded?.shape).toBe('oval');
  });

  it('makes a share URL', () => {
    const url = makeShareUrl(preset);
    expect(url).toContain('preset=');
  });
});