import { nailPath, renderNailPath, AnchorBox, NailShape, NailLength } from '../../lib/nailPath';

describe('nailPath.ts', () => {
  const anchor: AnchorBox = { x: 0, y: 0, width: 100, height: 200 };

  it('generates a path string for oval shape', () => {
    const d = nailPath('oval', 'med', anchor);
    expect(typeof d).toBe('string');
    expect(d.length).toBeGreaterThan(0);
  });

  it('applies renderNailPath transform', () => {
    const d = nailPath('square', 'short', anchor);
    const { transform } = renderNailPath(d, anchor);
    expect(transform).toContain('translate(0, 0)');
  });

  it('supports all NailShape values', () => {
    const shapes: NailShape[] = [
      'natural-round',
      'oval',
      'almond',
      'square',
      'squoval',
      'coffin',
      'stiletto',
    ];
    shapes.forEach(shape => {
      const d = nailPath(shape, 'med', anchor);
      expect(d).toMatch(/^M/); // path should start with M
    });
  });

  it('supports all NailLength values', () => {
    const lengths: NailLength[] = ['short', 'med', 'long'];
    lengths.forEach(len => {
      const d = nailPath('oval', len, anchor);
      expect(d).toContain('Z'); // closed path
    });
  });
});