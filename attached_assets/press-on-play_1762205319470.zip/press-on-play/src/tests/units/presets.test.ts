import { savePreset, loadPresets, deletePreset, NailPreset } from '../../lib/presets';

// Mock localStorage for testing
beforeEach(() => {
  let store: Record<string, string> = {};
  const localStorageMock = {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
  Object.defineProperty(window, 'localStorage', {
    value: localStorageMock,
    writable: true,
  });
});

describe('presets.ts', () => {
  const basePreset: NailPreset = {
    id: '1',
    name: 'Test Preset',
    shape: 'oval',
    length: 'med',
    baseColor: '#ff0000',
    finish: 'gloss',
    cuticleRatio: 0.15,
    shapeTools: {
      cuticleDepth: true,
      tipRoundness: true,
      taper: true,
      squovalRadius: true,
    },
    pattern: { kind: 'none' },
  };

  it('saves and loads a preset', () => {
    savePreset(basePreset);
    const all = loadPresets();
    expect(all.length).toBe(1);
    expect(all[0].name).toBe('Test Preset');
  });

  it('overwrites a preset with the same id', () => {
    savePreset(basePreset);
    const updated = { ...basePreset, name: 'Updated Preset' };
    savePreset(updated);
    const all = loadPresets();
    expect(all.length).toBe(1);
    expect(all[0].name).toBe('Updated Preset');
  });

  it('deletes a preset by id', () => {
    savePreset(basePreset);
    deletePreset('1');
    const all = loadPresets();
    expect(all.length).toBe(0);
  });
});