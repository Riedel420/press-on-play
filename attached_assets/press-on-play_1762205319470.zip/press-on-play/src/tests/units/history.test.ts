import { History, Command } from '../../features/history/commands';

describe('History', () => {
  type TestState = { value: number; };

  const increment: Command<TestState> = {
    do: (s) => ({ value: s.value + 1 }),
    undo: (s) => ({ value: s.value - 1 }),
    label: 'Increment',
  };

  const decrement: Command<TestState> = {
    do: (s) => ({ value: s.value - 1 }),
    undo: (s) => ({ value: s.value + 1 }),
    label: 'Decrement',
  };

  let history: History<TestState>;
  let state: TestState;

  beforeEach(() => {
    history = new History<TestState>();
    state = { value: 0 };
  });

  it('should apply a command and update state', () => {
    state = history.apply(increment, state);
    expect(state.value).toBe(1);
    expect(history.canUndo()).toBe(true);
    expect(history.canRedo()).toBe(false);
  });

  it('should undo a command', () => {
    state = history.apply(increment, state); // value = 1
    state = history.apply(increment, state); // value = 2
    state = history.undo(state);
    expect(state.value).toBe(1);
    expect(history.canUndo()).toBe(true);
    expect(history.canRedo()).toBe(true);
  });

  it('should redo a command', () => {
    state = history.apply(increment, state); // value = 1
    state = history.undo(state); // value = 0
    state = history.redo(state);
    expect(state.value).toBe(1);
    expect(history.canUndo()).toBe(true);
    expect(history.canRedo()).toBe(false);
  });

  it('should clear redo history when a new command is applied', () => {
    state = history.apply(increment, state); // value = 1
    state = history.apply(increment, state); // value = 2
    state = history.undo(state); // value = 1
    state = history.apply(decrement, state); // value = 0 (new command)
    expect(state.value).toBe(0);
    expect(history.canUndo()).toBe(true);
    expect(history.canRedo()).toBe(false); // Redo history should be cleared
  });

  it('should not undo if no commands in history', () => {
    state = history.undo(state);
    expect(state.value).toBe(0);
    expect(history.canUndo()).toBe(false);
  });

  it('should not redo if no commands to redo', () => {
    state = history.apply(increment, state); // value = 1
    state = history.redo(state); // still value = 1
    expect(state.value).toBe(1);
    expect(history.canRedo()).toBe(false);
  });
});