import { buildFinish, FinishStyle } from '../../lib/finishes';

describe('finishes.ts', () => {
  const styles: FinishStyle[] = [
    'none',
    'gloss',
    'matte',
    'chrome',
    'pearl',
    'shimmer',
    'opalimmer',
    'glittertop',
    'holographic',
  ];

  it('returns an object for each finish style', () => {
    styles.forEach(style => {
      const result = buildFinish(style);
      expect(typeof result).toBe('object');
    });
  });

  it('gloss includes gradient defs', () => {
    const gloss = buildFinish('gloss');
    expect(gloss.defs).toContain('<linearGradient');
    expect(gloss.attrs?.fill).toContain('url(#finish-gloss-grad)');
  });

  it('matte applies filter style', () => {
    const matte = buildFinish('matte');
    expect(matte.attrs?.style).toContain('brightness');
  });

  it('holographic includes rainbow stops', () => {
    const holo = buildFinish('holographic');
    expect(holo.defs).toContain('red');
    expect(holo.defs).toContain('violet');
  });
});