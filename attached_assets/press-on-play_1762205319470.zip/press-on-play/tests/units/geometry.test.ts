import { nailPath } from '../../lib/geometry';

describe('geometry.ts', () => {
  it('should generate a valid path for almond shape', () => {
    const path = nailPath(100, 200, 'almond', 'medium');
    expect(path).toMatch(/^M .* Z$/);
    expect(path).toContain('a'); // Should contain arc commands
  });

  it('should generate a valid path for stiletto shape', () => {
    const path = nailPath(100, 200, 'stiletto', 'long');
    expect(path).toMatch(/^M .* Z$/);
    expect(path).not.toContain('a'); // Stiletto should not contain arc commands
    expect(path).toContain('L'); // Should contain line commands
  });

  it('should produce different paths for different shapes', () => {
    const almondPath = nailPath(100, 200, 'almond', 'medium');
    const squarePath = nailPath(100, 200, 'square', 'medium');
    expect(almondPath).not.toEqual(squarePath);
  });

  it('should handle different dimensions', () => {
    const path1 = nailPath(50, 100, 'almond', 'short');
    const path2 = nailPath(100, 200, 'almond', 'short');
    expect(path1).not.toEqual(path2);
  });
});