// src/setupTests.ts
// This file is used by Jest to set up the testing environment.
// We need to mock localStorage for tests that run in Node.js (JSDOM).

const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
};

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

// Optionally, if you have @testing-library/jest-dom installed
import '@testing-library/jest-dom';