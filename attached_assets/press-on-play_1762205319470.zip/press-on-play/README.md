# Press‑On Play™

**Press‑On Play™** is a playful, browser‑based nail design playground built with **React + TypeScript**.  
It’s designed for families and casual players to explore nail art interactively, save and share presets, and experiment with finishes and patterns — all in a safe, accessible, and fun environment.

---

## ✨ Features

- 🎨 **Interactive Hand Canvas** — realistic nail shapes rendered on a hand image
- 🖌 **Shape & Length Controls** — oval, almond, square, squoval, coffin, stiletto, natural‑round
- 💅 **Finishes** — gloss, matte, chrome, pearl, shimmer, opalimmer, glittertop, holographic
- 🧩 **Patterns** — stripes, dots, marble overlays
- 💾 **Preset System** — save, load, delete, and share designs via URL
- 📱 **PWA Ready** — installable on desktop and mobile

---

## 🚀 Getting Started

### Prerequisites
- Node.js (>= 16)
- npm (>= 8)

